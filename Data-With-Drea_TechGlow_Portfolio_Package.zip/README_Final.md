# 🌿 Data With Drea | Tech Glow Edition

Hi, I'm Drea 👋🏾 — a recruiter turned developer, building systems that make work smarter, not harder.  
Currently pursuing my B.S. in Computer Science (AI & Automation focus) and documenting my journey into software engineering.

## 💫 About Me
- 🌍 Based in Cooper City, Florida  
- 🎓 BSCS @ WGU, graduating June 2026  
- 💼 8+ years in recruiting, analytics, & process optimization  
- 🚀 Career-changer bridging people, data & technology  

## 🧭 Learning Tracks
| Track | Focus | Tools |
|--------|--------|--------|
| AI & Automation | Chatbots, resume matching | Python, OpenAI, Pandas |
| Data Analytics | Dashboards, reporting | SQL, Power BI |
| Full Stack Dev | Recruiter tools | React, Flask, APIs |

## 🏗️ Featured Projects
| Project | Description | Tech |
|----------|--------------|------|
| MatchMaker AI | NLP-based resume matcher | Python, Pandas, scikit-learn |
| Workflow Genie | Automation Dashboard | Zapier, Airtable, Streamlit |
| InsightLens | Power BI Analytics Tool | SQL, Power BI, Streamlit |
| OpsOptima | Workflow Efficiency Tracker | Flask, JS |
| AutoApply Bot | Job automation assistant | Replit, Python |

## 🧰 Tech Stack
Python | SQL | React | Power BI | Flask | Zapier | Airtable | Streamlit | JavaScript | GitHub  

## 🌐 Portfolio
DataWithDrea.dev (coming soon)
