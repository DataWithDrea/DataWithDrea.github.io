AI Activity Studio — Streamlit Dashboard
Generates weekly GitHub & LinkedIn post ideas with Data With Drea footer.